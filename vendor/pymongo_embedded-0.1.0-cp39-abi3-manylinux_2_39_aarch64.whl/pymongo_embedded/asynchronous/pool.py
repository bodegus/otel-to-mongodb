from __future__ import annotations

from typing import Any

from pymongo.asynchronous.pool import AsyncConnection, Pool
from pymongo.errors import DocumentTooLarge, ProtocolError
from pymongo.hello import Hello
from pymongo.message import _OpMsg
from pymongo.monitoring import ConnectionClosedReason
from pymongo.pool_shared import _CancellationContext

from .._native import AsyncNativeClient
from ..common import (
    PENDING_ALREADY,
    PENDING_MISSING,
    Socket,
    describe,
    mismatched,
    too_large,
)


class _Interface:
    """What `AsyncConnection` expects a socket to be, for a connection that has none.

    `close` is a coroutine because the base class awaits it, and `is_closing` answers False
    because there is no socket to have been closed underneath us -- the connection's own
    `closed` flag is the whole truth, which is what `conn_closed` below returns.
    """

    def __init__(self) -> None:
        self.get_conn = Socket()

    async def close(self) -> None:
        pass

    def is_closing(self) -> bool:
        return False


class AsyncEmbeddedConnection(AsyncConnection):
    def __init__(
        self,
        runtime: AsyncNativeClient,
        pool: Pool,
        address: tuple[str, int],
        connection_id: int,
        is_sdam: bool,
    ) -> None:
        super().__init__(_Interface(), pool, address, connection_id, is_sdam)
        self._runtime = runtime
        self._pending: tuple[int, _OpMsg] | None = None

    async def _hello(self, topology_version: Any, heartbeat_frequency: Any) -> Hello:
        return describe(self)

    async def send_message(self, message: bytes, max_doc_size: int) -> None:
        """Runs the command, rather than sending it.

        There is no socket and so no send that could be separated from a receive: the reply is
        already in hand when this returns, and `receive_message` hands over what was kept here.
        Awaiting it is what makes the whole thing worth building -- the event loop is free for
        the length of the command, and cancelling the task stops the engine rather than merely
        stopping the wait.
        """
        if max_doc_size > self.max_bson_size:
            raise DocumentTooLarge(too_large(max_doc_size, self.max_bson_size))
        if self._pending is not None:
            raise ProtocolError(PENDING_ALREADY)
        try:
            request_id, more_to_come, response = await self._runtime.round_trip(message)
            if not more_to_come:
                self._pending = request_id, _OpMsg(0, response)
        except BaseException as error:
            await self._raise_connection_failure(error)

    async def receive_message(self, request_id: int | None) -> _OpMsg:
        try:
            pending, self._pending = self._pending, None
            if pending is None:
                raise ProtocolError(PENDING_MISSING)
            response_to, response = pending
            if request_id is not None and request_id != response_to:
                raise ProtocolError(mismatched(response_to, request_id))
            return response
        except BaseException as error:
            await self._raise_connection_failure(error)

    def conn_closed(self) -> bool:
        return self.closed


class AsyncEmbeddedPool(Pool):
    def __init__(self, *args: Any, runtime: AsyncNativeClient, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._runtime = runtime
        self._check_interval_seconds = None

    async def connect(self, handler: Any = None) -> AsyncEmbeddedConnection:
        async with self.lock:
            connection_id = self.next_connection_id
            self.next_connection_id += 1
            temporary_context = _CancellationContext()
            self.active_contexts.add(temporary_context)
        self._telemetry.connection_created(connection_id)

        connection = None
        # Whether the handshake got through, which is what decides below whether the failure
        # is one `_handle_connection_error` should be labelling. Tracked rather than inferred
        # for the same reason the base class tracks it: an `is_sdam` pool performs no
        # handshake, so "did it succeed" and "was there one" are different questions.
        completed_hello = False
        try:
            connection = AsyncEmbeddedConnection(
                self._runtime, self, self.address, connection_id, self.is_sdam
            )
            async with self.lock:
                self.active_contexts.add(connection.cancel_context)
                self.active_contexts.discard(temporary_context)
            if temporary_context.cancelled:
                connection.cancel_context.cancel()
            if not self.is_sdam:
                await connection.hello()
                completed_hello = True
                self.is_writable = connection.is_writable
            if handler:
                handler.contribute_socket(connection, completed_handshake=False)
            await connection.authenticate()
        except BaseException as error:
            async with self.lock:
                self.active_contexts.discard(temporary_context)
                if connection is not None:
                    self.active_contexts.discard(connection.cancel_context)
            if not completed_hello:
                self._handle_connection_error(error)
            if connection is None:
                self._telemetry.connection_closed(
                    connection_id, ConnectionClosedReason.ERROR
                )
            else:
                await connection.close_conn(ConnectionClosedReason.ERROR)
            raise

        # Outside the `try`, as in the base class: a cluster time that failed to be gossiped
        # is not a connection that failed to be made, and treating it as one would close a
        # working connection and report it as a connection error.
        if handler:
            await handler.client._topology.receive_cluster_time(connection._cluster_time)
        return connection
